/**
 * CodeVent Digital — pwa-register.js
 * Drop ONE <script src="pwa-register.js"></script> into every HTML page (before </body>).
 * Handles: SW registration, auto-update notification, install prompt (A2HS).
 */

(function () {
  'use strict';

  /* ── 1. Register Service Worker ──────────────────────────────────────── */
  if (!('serviceWorker' in navigator)) return;

  const SW_URL = '/codevent-digital/service-worker.js';

  window.addEventListener('load', async () => {
    try {
      const reg = await navigator.serviceWorker.register(SW_URL, {
        scope: '/codevent-digital/'
      });

      /* ── 2. Auto-update: detect new SW and prompt ── */
      reg.addEventListener('updatefound', () => {
        const newWorker = reg.installing;
        newWorker.addEventListener('statechange', () => {
          if (newWorker.state === 'installed' && navigator.serviceWorker.controller) {
            showUpdateBanner(newWorker);
          }
        });
      });

      /* ── 3. Handle controller change → reload ── */
      let refreshing = false;
      navigator.serviceWorker.addEventListener('controllerchange', () => {
        if (!refreshing) {
          refreshing = true;
          window.location.reload();
        }
      });

      /* ── 4. Periodic update check (every 60s while tab open) ── */
      setInterval(() => reg.update(), 60_000);

    } catch (err) {
      console.warn('[PWA] SW registration failed:', err);
    }
  });

  /* ── Update Banner ───────────────────────────────────────────────────── */
  function showUpdateBanner(newWorker) {
    if (document.getElementById('cv-update-banner')) return;

    const banner = Object.assign(document.createElement('div'), {
      id: 'cv-update-banner',
      innerHTML: `
        <span>🚀 A new version of CodeVent is ready!</span>
        <button id="cv-update-btn">Update Now</button>
        <button id="cv-update-dismiss" aria-label="Dismiss">✕</button>
      `
    });

    Object.assign(banner.style, {
      position:   'fixed',
      bottom:     '1.25rem',
      left:       '50%',
      transform:  'translateX(-50%)',
      background: '#5b4cff',
      color:      '#fff',
      display:    'flex',
      alignItems: 'center',
      gap:        '.75rem',
      padding:    '.75rem 1.25rem',
      borderRadius: '.65rem',
      boxShadow:  '0 4px 24px rgba(91,76,255,.45)',
      fontSize:   '.88rem',
      fontFamily: 'system-ui, sans-serif',
      zIndex:     '9999',
      whiteSpace: 'nowrap',
      maxWidth:   'calc(100vw - 2.5rem)'
    });

    const btnStyle = {
      background: 'rgba(255,255,255,.2)',
      border: 'none',
      color: '#fff',
      padding: '.4rem .85rem',
      borderRadius: '.4rem',
      cursor: 'pointer',
      fontSize: '.85rem',
      fontWeight: '600'
    };

    ['cv-update-btn', 'cv-update-dismiss'].forEach(id => {
      const el = banner.querySelector(`#${id}`);
      if (el) Object.assign(el.style, btnStyle);
    });

    document.body.appendChild(banner);

    banner.querySelector('#cv-update-btn').addEventListener('click', () => {
      newWorker.postMessage({ type: 'SKIP_WAITING' });
    });

    banner.querySelector('#cv-update-dismiss').addEventListener('click', () => {
      banner.remove();
    });
  }

  /* ── 5. Add-to-Home-Screen Install Prompt ────────────────────────────── */
  let deferredPrompt = null;

  window.addEventListener('beforeinstallprompt', e => {
    e.preventDefault();
    deferredPrompt = e;
    showInstallBadge();
  });

  function showInstallBadge() {
    if (document.getElementById('cv-install-badge')) return;

    const badge = Object.assign(document.createElement('button'), {
      id: 'cv-install-badge',
      textContent: '⬇ Install App',
      title: 'Install CodeVent Digital as an app'
    });

    Object.assign(badge.style, {
      position:     'fixed',
      bottom:       '1.25rem',
      right:        '1.25rem',
      background:   '#00e5a0',
      color:        '#0d0f1a',
      border:       'none',
      padding:      '.65rem 1.2rem',
      borderRadius: '99px',
      fontWeight:   '700',
      fontSize:     '.85rem',
      fontFamily:   'system-ui, sans-serif',
      cursor:       'pointer',
      boxShadow:    '0 4px 18px rgba(0,229,160,.35)',
      zIndex:       '9998',
      transition:   'opacity .2s'
    });

    badge.addEventListener('mouseenter', () => badge.style.opacity = '.85');
    badge.addEventListener('mouseleave', () => badge.style.opacity = '1');

    badge.addEventListener('click', async () => {
      if (!deferredPrompt) return;
      deferredPrompt.prompt();
      const { outcome } = await deferredPrompt.userChoice;
      if (outcome === 'accepted') badge.remove();
      deferredPrompt = null;
    });

    document.body.appendChild(badge);
  }

  window.addEventListener('appinstalled', () => {
    const badge = document.getElementById('cv-install-badge');
    if (badge) badge.remove();
    deferredPrompt = null;
    console.log('[PWA] CodeVent Digital installed successfully.');
  });

})();
